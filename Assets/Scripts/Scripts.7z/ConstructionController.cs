﻿using System;
using System.Linq;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConstructionArgs : EventArgs
{
    public Construction CurrentConstruction { get; set; }
}

public class ConstructionController : MonoBehaviour {
    [SerializeField]
    private GameObject constructionParent;


    private Dictionary<string, Construction> constructionPatterns;

    private List<Construction> constructions;

    private ConstructionFunctions constructionFunctions;

    public EventHandler<ConstructionArgs> ConstructionPlaced;

    // Use this for initialization
    private void Awake()
    {
        constructionFunctions = new ConstructionFunctions();
        constructionPatterns = new Dictionary<string, Construction>();
        constructions = new List<Construction>();
        CreateConstructionsList();
    }

    void Start()
    {
        
    }

    private void CreateConstructionsList()
    {
        string path = Application.streamingAssetsPath + "/JSON/constructions.json";
        ConstructionListJSONHelper constructionsList = new ConstructionListJSONHelper();
        using (StreamReader stream = new StreamReader(path))
        {
            string json = stream.ReadToEnd();
            constructionsList = JsonUtility.FromJson<ConstructionListJSONHelper>(json);
        }
       
        foreach(ConstructionJSONHelper cJSON in constructionsList.Constructions)
        {
            Construction b = DeserelizeJSONHelper(cJSON);
            constructionPatterns.Add(b.ObjectName, b);
        }
    }

    private Construction DeserelizeJSONHelper(ConstructionJSONHelper constructionJSON)
    {
        Resources res = new Resources();
        foreach(JInteger r in constructionJSON.Resource)
        {
            res.SetResource((ResourceName)Enum.Parse(typeof(ResourceName), r.name), r.value);
        }
        Construction c = new Construction(constructionJSON.Name, 
            SpriteManager.current.GetSprite("Construction", constructionJSON.SpriteName), 
            constructionJSON.TileSizeWidth, 
            constructionJSON.TileSizeHeigth, 
            res);
        foreach(JFloat param in constructionJSON.Param)
        {
            c.SetParam(param.name, param.value);
        }
        foreach(string action in constructionJSON.OnUpdateAction)
        {
            c.RegisterOnUpdate(constructionFunctions.GetAction(action));
        }

        return c;
    }

    private void CreateConstructionButtons()
    {

    }

    public void PlaceBuilding(string name, Tile t)
    {
        if (constructionPatterns[name].IsBuildTileVaild(t))
        {
            Construction c = (Construction)constructionPatterns[name].Clone(t);

            c.Place();
            c.ObjectHandler.transform.SetParent(constructionParent.transform);

            constructions.Add(c);

            OnConstructionPlaced(c);
        } else
        {
            //Debug.Log("Место занято");
        }
    }

    // Update is called once per frame
    void Update()
    {
        foreach (Construction construction in constructions)
        {
            construction.Update(GameManager.Instance.GameSpeed);
        }
    }

    public Construction GetPattern(string name)
    {
        if (!constructionPatterns.ContainsKey(name))
        {
            Debug.LogError("В базе данных прототипов отсутвует " + name);
            return null;
        }

        return constructionPatterns[name];
    }

    public Construction[] GetAllPatterns()
    {
        return constructionPatterns.Values.ToArray();
    }

    public Transform GetConstructionParent()
    {
        return constructionParent.transform;
    }

    protected virtual void OnConstructionPlaced(Construction c)
    {
        if (ConstructionPlaced != null)
        {
            ConstructionPlaced(this, new ConstructionArgs() { CurrentConstruction = c });
        }
    }
}
